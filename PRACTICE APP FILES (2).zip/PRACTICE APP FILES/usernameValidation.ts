/**
 * Username validation utilities
 */

export interface UsernameValidationResult {
  isValid: boolean;
  error?: string;
  sanitized?: string;
}

// Username requirements
const MIN_LENGTH = 3;
const MAX_LENGTH = 20;
const ALLOWED_PATTERN = /^[a-zA-Z0-9_-]+$/;

// Basic profanity filter (can be expanded)
const RESTRICTED_WORDS = [
  'admin',
  'moderator',
  'support',
  'official',
  'vibeofficial',
];

/**
 * Validates and sanitizes a username
 */
export function validateUsername(username: string): UsernameValidationResult {
  // Trim whitespace
  const trimmed = username.trim();

  // Check if empty
  if (!trimmed) {
    return {
      isValid: false,
      error: 'Username cannot be empty',
    };
  }

  // Check length
  if (trimmed.length < MIN_LENGTH) {
    return {
      isValid: false,
      error: `Username must be at least ${MIN_LENGTH} characters`,
    };
  }

  if (trimmed.length > MAX_LENGTH) {
    return {
      isValid: false,
      error: `Username must be ${MAX_LENGTH} characters or less`,
    };
  }

  // Check allowed characters
  if (!ALLOWED_PATTERN.test(trimmed)) {
    return {
      isValid: false,
      error: 'Username can only contain letters, numbers, underscores, and hyphens',
    };
  }

  // Check for restricted words
  const lowerUsername = trimmed.toLowerCase();
  const hasRestrictedWord = RESTRICTED_WORDS.some(word => 
    lowerUsername.includes(word)
  );

  if (hasRestrictedWord) {
    return {
      isValid: false,
      error: 'This username contains restricted words',
    };
  }

  // All checks passed
  return {
    isValid: true,
    sanitized: trimmed,
  };
}

/**
 * Sanitizes username for display (prevent XSS)
 */
export function sanitizeUsername(username: string): string {
  return username
    .trim()
    .replace(/[<>'"]/g, '')
    .substring(0, MAX_LENGTH);
}

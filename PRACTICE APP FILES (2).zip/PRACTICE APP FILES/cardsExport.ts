// This file re-exports cards with rarities assigned
export { practiceCards, rarityConfig, type PracticeCard, type CardRarity } from './cardsWithRarity';
